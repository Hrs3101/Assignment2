
func myfunc1()
{
  for i in 1...5
  {

   for k in stride(from:5, to:i , by:-1 )  
    {
    print(" ",terminator : "")
    }
    for j in 1...i
    {
      print("* ",terminator : "")
    }
    print(" ")
    
  }

}
func myfunc2()
{
  for i in 1...5
  {
    for j in 1...i
    {
      print("* ",terminator : "")
    }
    print(" ")
    
  }
}
func myfunc3()
{
  for i in 1...5
  {

   for k in stride(from:6, to:i ,by:-1 )  
    {
    print("  ",terminator : "")
    }
    for j in 1...i
    {
      print(" *",terminator : "")
    }
    print(" ")
    
  }
}
func myfunc4()
{
  for i in 1...5
  {

   for k in stride(from:5, to:i,by:-1 )  
    {
    print(" ",terminator : "")
    }
    for j in 1...i
    {
      print("* ",terminator : "")
    }
    print(" ")
    
  }

  for p in 1...4
  {
    for q in 1...p
    {
      print(" ",terminator : "")
    }
    for s in stride(from:5,to:p,by:-1)
    {
      print("* ",terminator : "")
    }
    print("")
  }
}

 func myfunc5()
{
  for i in 1...5
  {
     for k in stride(from:6, to:i,by:-1 )  
    {
    print(" *",terminator : "")
    }
    print(" ")
  }
}
func myfunc6()
{
  for i in 1...5
  {
    for j in 1...i
    {
      print("* ",terminator : "")
    }
    print(" ")
  }
  for i in 1...5
  {
     for k in stride(from:5, to:i,by:-1 )  
    {
    print("* ",terminator : "")
    }
    print(" ")
  }
}
func myfunc7()
{
   for i in 1...5
  {
     for k in stride(from:6, to:i,by:-1 )  
    {
    print("* ",terminator : "")
    }
    print(" ")
  }
  for i in 1...5
  {
    for j in 1...i
    {
      print("* ",terminator : "")
    }
    print(" ")
  }
}
print("Pyramid")
myfunc1()
print("Right Triangle")
myfunc2()
print("Mirrored Right Triangle")
myfunc3()
print("Dimond")
myfunc4()
print("Downward Triangle")
myfunc5()
print("Right Pascal's Triangle")
myfunc6()
print("Sandglass Pattern")
myfunc7()
